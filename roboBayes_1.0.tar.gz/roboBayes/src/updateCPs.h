#include "Parameters.h"
#include "Unit.h"

void updateCPs(const Unit& prevUnit,
               Unit& newUnit, 
               const int itime,
               const Parameters& parms);
