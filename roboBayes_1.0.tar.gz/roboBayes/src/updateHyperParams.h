#include "Model.h"
#include "Parameters.h"
#include "Unit.h"

void updateHyperParams(const Model& model0,
                       Model& newModel,
                       const Parameters& parms);
